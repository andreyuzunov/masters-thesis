<?php
/*
    Copyright (C) 2013 Andrey Uzunov

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

error_reporting(E_ALL);
require_once(dirname(__FILE__).'/include/functions.php');
set_error_handler("myErrorHandler");
if($argc != 4)
bug(__LINE__, "usage: input-file site output-file\n");

function reorder_requests($arr)
{
  //no precise reorder, as time is always the same (not possible to distinguish page loads in later script)
  global $argv;
  global $mistaken_reqs;
  global $mistaken_reqs2;

  $key = -1;
  $bad_reqs = false;
  
  for($i = 0 ; $i<count($arr)-1; ++$i)
  {
    $referers = array();
    for($k = $i ; $k<count($arr); ++$k)
    {
      $referers[]=$argv[2].$arr[$k][4];
    }
    
    if(!in_array($arr[$i][8],$referers))
      continue;
    
    for($j = $i + 1 ; $j<count($arr); ++$j)
    {
      if(!in_array($arr[$j][8],$referers))
      {
        $temp = $arr[$j];
        $arr[$j] = $arr[$i];
        $arr[$i] = $temp;
        
        break;
      }
    }
  }
  
  return $arr;
}

function write_lines()
{
  global $arr_time;
  global $written;
  global $whandle;
  
  foreach($arr_time as $skey=>$session)
  {
    if(count($session) > 1)
    {
      $session = reorder_requests($session);
    }
    foreach($session as $key=>$req)
    {
      $written++;
      fwrite($whandle,$req[0]);
    }
    unset($arr_time[$skey]);
  }
}

$handle = fopen($argv[1], 'r');
$whandle = fopen($argv[3], 'w');
if(!$handle) bug(__LINE__);
if(!$whandle) bug(__LINE__);

$browscap_filtered = 0;

$written = 0;

$arr_time = array();
$uas_flags = array();
$uas_arrays = array();

$last_time = 0;

while (($line = fgets($handle)) !== false)
{
  $arr = regexp_log1($line);
  if(!is_array($arr))
  {
    $str = varDumpToString($arr);
    $str .= varDumpToString($line);
    bug(__LINE__, $str);
  }

  if(!isset($uas_flags[$arr[9]]))
  {
    $beg = time();
    $browser = get_browser($arr[9], true);
    if(false != $browser['crawler'] || 'DefaultProperties' === $browser['browser'] || 'Default Browser' === $browser['browser'])
    {
      $uas_flags[$arr[9]] = 0;
      $browscap_filtered++;
      continue;
    }
    else
    {
      $uas_arrays[$arr[9]] = $browser;
      unset($uas_arrays[$arr[9]]['browser_name_regex']);
      $uas_flags[$arr[9]] = 1;
    }
  }
  else if(0 === $uas_flags[$arr[9]])
  {
    $browscap_filtered++;
    continue;
  }

  $cur_time = strtotime($arr[2]);
  if($cur_time>$last_time)
  {
    write_lines();
  }
  elseif($cur_time < $last_time)
  {
    $str = varDumpToString($arr_time);
    $str .= varDumpToString($req);
    $str .= varDumpToString(date('r',$last_time));
    bug(__LINE__,'not ordered '. $str);
  }

  if(0 === strpos($arr[8], 'http://')) $arr[8] = substr($arr[8], strlen('http://'));
  else if(0 === strpos($arr[8], 'https://')) $arr[8] = substr($arr[8], strlen('https://'));
  if(0 === strpos($arr[8], 'www.')) $arr[8] = substr($arr[8], strlen('www.'));
  $key =   $cur_time.' - '.$arr[1] .' - ' .$arr[9];
  $arr_time[$key][] = $arr;
  
  $last_time = $cur_time;
}

fclose($handle);

if(count($arr_time) > 0)
{
  write_lines();
}

fclose($whandle);

if(!empty($arr_time))
  bug(__LINE__, 'not processed');
  
if($written > 0){
if(empty($uas_arrays))
  bug(__LINE__, 'uas_arrays');

$json = json_encode($uas_arrays);
    
if(empty($json))
  bug(__LINE__, 'json'.json_last_error());
  
$uas_cache_file = $argv[3].'-browsers-cache';
$ret = file_put_contents($uas_cache_file, $json);
    
if(!($ret > 0))
  bug(__LINE__, 'file_put_contents');
  
echo $uas_cache_file." file written (browser cache for next scritps).\n";
}

echo $browscap_filtered." lines filtered by browscap.ini.\n";
echo $written." lines written.\n";
echo count($uas_arrays)." different browsers.\n";
?>
