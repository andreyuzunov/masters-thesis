#!/bin/bash -e

#    Copyright (C) 2013 Andrey Uzunov
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

if [ "1" -ne "$#" ]
then
        echo "usage: pushisp.sh raw-access-log"
        exit

fi

source $(dirname $0)/include/common.sh

FILTERED_AND_SORTED="$INPUT"

    writelog "Filter with browscap.ini (SLOW!) (source file is $FILTERED_AND_SORTED)..."

    REORDERED="temp-${BASE_INPUT}-filtered"

    PHPOUT=`php "$DIR/isp-browsers.php" "$FILTERED_AND_SORTED" "$REORDERED" 2>&1`
    
    writelog "PHP said: ${PHPOUT}"
    
    loglines "$REORDERED"
    
    if [ "$LINES" -ge "1" ]
    then

    #browsers and is_mobile option
    for BROWSERS in 0 1 2
    do
      #pageload timeout option
      for PL_TIMEOUT in 1000
      do
        #session timeout option
        for SESS_TIMEOUT in 180000 3600000
        do
          #size limit
          for SIZE in -1
          do
            #using history per user
            for HISTORY in 0 1
            do
              #different thresholds
              for THRESHOLD in 0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1
              do
                #different algos
                for ALGO in basic basic-less basic-more
                do
                  OUTPUT_OPTION="1"
                  
                  if [ ! -f "$ALGOS_LOG" ]
                  then
                    #write CSV header
                    writelog "CSV header will be written"
                    OUTPUT_OPTION="2"
                  fi
                  
                  #echo "${ALGO}.php ${SESS_TIMEOUT} ${PL_TIMEOUT} 20000 ${REORDERED} 1 $THRESHOLD -1 ${BROWSERS} ${OUTPUT_OPTION} ${SIZE} ${HISTORY}"
                  run_test "${ALGO}.php ${SESS_TIMEOUT} ${PL_TIMEOUT} 20000 ${REORDERED} 1 $THRESHOLD -1 ${BROWSERS} ${OUTPUT_OPTION} ${SIZE} ${HISTORY}"
                done
              done
            done
          done
        done
      done
    done
    
    fi
    
      rm "$REORDERED"
      rm "${REORDERED}-browsers-cache" || true

#if ls plot-*.png &> /dev/null;
#then
#  TARFILE="plots-${COMMON_FILENAME}.tar.gz"
#
#  writelog "Writing plots to ${TARFILE}..."
#
#  tar -zcvf "$TARFILE" plot-*.png > /dev/null
#
#  rm plot-*.png
#fi

writelog "SUCCESS. EXIT"

exit 
