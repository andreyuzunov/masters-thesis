<?php
/*
    Copyright (C) 2013 Andrey Uzunov

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

error_reporting(E_ALL);
set_error_handler("myErrorHandler");

//options
$timeout_session = $argv[1];
$timeout_pageload = $argv[2];
$timeout_pageload_max = $argv[3];
$input_file = $argv[4];
$threshold_num = $argv[5];
$threshold_ratio = $argv[6];
$max_num_to_push = $argv[7];
$option_browsers = $argv[8];
$option_output = $argv[9];
$option_max_push_size = $argv[10];
$option_history = $argv[11];
$option_log_format= 13 == $argc ? $argv[12] : 0;

//counters
$num_total_lines = 0;
$num_pushed = 0;
$num_sessions = 0;
$num_pageloads = 0;
$num_assets = 0;
$num_total_assets = 0;
$num_assets_in_bad_pageload = 0;
$num_discarded_assets = 0;
$num_not_used_pageloads = 0;
$num_mobile = 0;
$num_mistakes = 0;
$num_favicons = 0;
$num_not_pushed_big = 0;
$num_hits_pushed_for_diff_pageload = 0;

//working data
$have_size = -1;
$cur_browser = array('browser'=>0);
$sessions = array();
$sessions_end_time = array();
$pages = array();
$assets = array();
$total_size_per_asset = array();

//statistics data
$begin = 0;
$end = 0;
$size_pages = array();
$size_assets = array();
$size_mistakes = array();
$session_length = array();
$stat_spec_pageload = array(array(), array(), array(), array(), array(), array());
for($i = 0; $i<=5; ++$i)
{
  $stat_spec_pageload[$i]['num'] = 0;
  $stat_spec_pageload[$i]['assets'] = array();
  $stat_spec_pageload[$i]['pushes'] = array();
  $stat_spec_pageload[$i]['mistakes'] = array();
}
$browsers_cache = array();
$browsers_num = array();
$dups = array();
$stat_gnuplot = array();

if($option_browsers > 0)
{
$browsers_cache = json_decode(file_get_contents($input_file.'-browsers-cache'),true);
if(empty($browsers_cache))
  bug(__LINE__, 'no json browser cache');
  
foreach($browsers_cache as $ua=>$browser)
  $browsers_num[$ua] = 0;
}

bcscale(7);

function is_allowed_for_push($url)
{
  global $option_max_push_size;
  global $total_size_per_asset;
  global $assets;
  global $have_size;
  global $num_not_pushed_big;
  
  if(-1 == $option_max_push_size
    || $have_size < 1)
      return true;
      
  if(round(bcdiv($total_size_per_asset[$url], $assets[$url])) <= $option_max_push_size)
  {
    return true;
  }
  else
  {
    ++$num_not_pushed_big;
    return false;
  }
}

function is_asset($url)
{
  global $assets;
  global $pages;
  global $dups;
  
  if(empty($assets[$url]))
    return FALSE;
    
  if(empty($pages[$url]))
    return TRUE;
    
  return $assets[$url] >= $pages[$url];
}

function record_asset($url, $size)
{
  global $assets;
  global $pages;
  global $dups;
  global $total_size_per_asset;
  global $have_size;
  
  $size = intval($size);
  if($have_size > 0 && $size < 0)
    bug(__LINE__);
  
  if(!isset($assets[$url]))
  {
    $assets[$url] = 1;
    if($have_size > 0)
      $total_size_per_asset[$url] = $size;
  }
  else
  {
    ++$assets[$url];
    if($have_size > 0)
      $total_size_per_asset[$url] += $size;
  }
  if(isset($pages[$url]))
  {
    if(!isset($dups[$url]))
      $dups[$url] = 1;
    else
      ++$dups[$url];
  }
}

function record_page($url)
{
  global $assets;
  global $pages;
  global $dups;
  
  if(!isset($pages[$url]))
    $pages[$url] = 1;
  else
    ++$pages[$url];
  if(isset($assets[$url]))
  {
    if(!isset($dups[$url]))
      $dups[$url] = 1;
    else
      ++$dups[$url];
  }
}

function check_session_timeout($timestamp_ms)
{
  global $sessions;
  global $sessions_end_time;
  global $timeout_session;
  global $stat_gnuplot;
  global $num_mistakes;
  global $num_pushed;
  global $num_total_lines;
  global $session_length;
  global $stat_spec_pageload;
  global $size_mistakes;
  global $assets;
  global $total_size_per_asset;
  global $have_size;
  
  foreach($sessions_end_time as $key=>$end_time)
  {
    if($end_time + $timeout_session < $timestamp_ms)
    {
      foreach($sessions[$key]['pageloads'] as $order=>$pageload)
      {
        $mistakes = 0;
        if(isset($pageload['pushed']))
        {
          foreach($pageload['pushed'] as $p_url=>$pushed)
          {
            $mistakes += $pushed;
            if($have_size > 0)
              $size_mistakes[] = round(bcdiv($total_size_per_asset[$p_url], $assets[$p_url]));
          }
            
          $num_mistakes += $mistakes;
        }
        $k = $order < 5 ? $order : 5;
        if(!isset($stat_spec_pageload[$k]['num']))
          $stat_spec_pageload[$k]['num'] = 0;
        ++$stat_spec_pageload[$k]['num'];
        $stat_spec_pageload[$k]['assets'][] = $pageload['num_assets'];
        $stat_spec_pageload[$k]['pushes'][] = $pageload['num_pushes'];
        $stat_spec_pageload[$k]['mistakes'][] = $mistakes;
      }
      cb_timedout_session($key, $timestamp_ms);
      $stat_gnuplot[$num_total_lines] = array($num_mistakes,$num_pushed);
      $session_length[] = $sessions[$key]['end_time'] - $sessions[$key]['begin_time'];
      unset($sessions[$key]);
      unset($sessions_end_time[$key]);
    }
    else break;
  }
}

function parse_request($session_id, $timestamp_ms, $url, $status, $method, $useragent, $size = -1)
{
  global $begin;
  global $end;
  global $sessions;
  global $sessions_end_time;
  global $num_pageloads;
  global $num_sessions;
  global $num_total_lines;
  global $num_favicons;
  global $timeout_pageload;
  global $timeout_pageload_max;
  global $num_not_used_pageloads;
  global $num_discarded_assets;
  global $cur_browser;
  global $num_assets;
  global $num_assets_in_bad_pageload;
  global $option_browsers;
  global $browsers_cache;
  global $num_mobile;
  global $num_total_assets;
  global $size_assets;
  global $size_pages;
  global $have_size;
  global $browsers_cache;
  global $browsers_num;
  
  ++$num_total_lines;
  
  if(empty($begin))
    $begin = $timestamp_ms;
  if($end > $timestamp_ms)
    bug(__LINE__, 'ERROR: the input file is not sorted ');
  $end = $timestamp_ms;
  
  if(-1 == $have_size)
    $have_size = $size >= 0 ? 1 : 0;
  
  $pos = strpos($url, '/');
  if(FALSE !== $pos && strpos($url, '/favicon.ico') === $pos)
  {
    //bug for privoxy logs: data contains http:// and this block is never entered
    ++$num_favicons;
    return;
  }
  
  if($option_browsers > 0)
  {
    if(isset($browsers_cache[$useragent]))
      $browser = $browsers_cache[$useragent];
    else
    {
      bug(__LINE__, 'no browser in the cache?');
      //SLOW!
      $browser = get_browser($useragent, true);
      $browsers_cache[$useragent] = $browser;
      $browsers_num[$useragent] = 0;
    }
    
    if(2 == $option_browsers)
      $cur_browser = $browser;
    
    ++$browsers_num[$useragent];
    if(true == $browser['ismobiledevice'] || '%' === $useragent)
    {
      ++$num_mobile;
      return;
    }
  }
    
  check_session_timeout($timestamp_ms);
  
  if(empty($sessions[$session_id]))
  {
    //new session
    ++$num_sessions;
    $session = array();
    $session['begin_time'] = $timestamp_ms;
    $session['pageloads'] = array();
    $sessions[$session_id] = $session;
    cb_new_session($session_id, $timestamp_ms);
  }
  else
  {
    //reuse session
    cb_reuse_session($session_id, $timestamp_ms);
  }

  $session = &$sessions[$session_id];
  $session['end_time'] = $timestamp_ms;
  unset($sessions_end_time[$session_id]);
  $sessions_end_time[$session_id] = $timestamp_ms;
  
  if(!empty($session['pageloads'])
  && ($session['pageloads'][count($session['pageloads']) - 1]['end_time'] + $timeout_pageload_max) >= $timestamp_ms 
  && (($session['pageloads'][count($session['pageloads']) - 1]['end_time'] + $timeout_pageload) >= $timestamp_ms
   || is_asset($url)))
  {
    //request for additional asset within the last page load for the session
    ++$num_total_assets;
    $pageload = &$session['pageloads'][count($session['pageloads']) - 1];
    if(false == $pageload['not_for_push'])
    {
      if(200 == $status && 'GET' == $method)
      {
        ++$pageload['num_assets'];
        $pageload['resources'][] = $url;
        $pageload['end_time'] = $timestamp_ms;
        unset($pageload);
        record_asset($url, $size);
        ++$num_assets;
        if($size > 0)
          $size_assets[] = $size;
        cb_request_resource($session_id, $timestamp_ms, $url);
      }
      else
        ++$num_discarded_assets;
    }
    else
      ++$num_assets_in_bad_pageload;
  }
  else
  {
    //first request in a pageload (html)
    ++$num_pageloads;
    $pageload = array();
    $pageload['first_url'] = $url;
    $pageload['begin_time'] = $timestamp_ms;
    $pageload['resources'][] = $url;
    $pageload['end_time'] = $timestamp_ms;
    $pageload['not_for_push'] = 200 != $status && 301 != $status && 302 != $status;
    if(true == $pageload['not_for_push'])
      ++$num_not_used_pageloads;
    $session['pageloads'][] = &$pageload;
    
    if(false == $pageload['not_for_push'])
    {
      record_page($url);
      if($size > 0)
        $size_pages[] = $size;
      cb_request_page($session_id, $timestamp_ms, $url);
    }
    $pageload['num_assets'] = 0;
    $pageload['num_pushes'] = !empty($pageload['pushed']) ? count($pageload['pushed']) : 0;
    unset($pageload);
  }
  
  unset($session);
}

function print_general_stat($title='unknown')
{
  global $begin;
  global $end;
  global $input_file;
  global $num_total_lines;
  global $num_sessions;
  global $num_pageloads;
  global $num_assets;
  global $num_mobile;
  global $num_pushed;
  global $num_mistakes;
  global $num_both_page_and_asset;
  global $pages;
  global $assets;
  global $size_pages;
  global $size_assets;
  global $size_mistakes;
  global $session_length;
  global $stat_spec_pageload;
  global $num_favicons;
  global $num_assets_in_bad_pageload;
  global $dups;
  global $num_total_assets;
  global $num_not_used_pageloads;
  global $num_discarded_assets;
  global $sessions;
  global $timeout_session;
  global $have_size;
  global $browsers_cache;
  global $browsers_num;
  global $num_not_pushed_big;
  global $num_hits_pushed_for_diff_pageload;
  
  global $option_output;
  
  if(!empty($sessions)) bug(__LINE__);
  
  asort($pages);
  $temp =  array_slice($pages,intval(count($pages)/2),1);
  $page_frequency_median = array_pop($temp);
  $temp = array_slice($pages,round(count($pages)*3/4),1);
  $page_frequency_3rd = array_pop($temp);
  
  asort($assets);
  $temp = array_slice($assets,intval(count($assets)/2),1);
  $asset_frequency_median = array_pop($temp);
  $temp = array_slice($assets,round(count($assets)*3/4),1);
  $asset_frequency_3rd = array_pop($temp);
  
  $total_num_dups = 0;
  foreach($pages as $page=>$p)
  {
    if(!empty($assets[$page]))
      $total_num_dups += min($assets[$page], $p);
  }
  
  if($have_size > 0)
  {
    sort($size_pages);
    $size_pages_median = $size_pages[intval(count($size_pages)/2)];
    $size_pages_sum = array_sum($size_pages);
    
    sort($size_assets);
    $size_assets_median = $size_assets[intval(count($size_assets)/2)];
    $size_assets_sum = array_sum($size_assets);
    
    if(!empty($size_mistakes))
    {
      sort($size_mistakes);
      $size_mistakes_median = $size_mistakes[intval(count($size_mistakes)/2)];
      $size_mistakes_sum = array_sum($size_mistakes);
    }
    
    $total_size = $size_pages_sum + $size_assets_sum;
  }
  
  sort($session_length);
  $session_length_median = $session_length[intval(count($session_length)/2)];
  $session_length_average = round(bcdiv(array_sum($session_length), count($session_length)),6);
  
  for($i = 0; $i <= 5; ++$i)
  {
    if(!empty($stat_spec_pageload[$i]))
    {
      sort($stat_spec_pageload[$i]['assets']);
      sort($stat_spec_pageload[$i]['pushes']);
      sort($stat_spec_pageload[$i]['mistakes']);
    }
  }
  
  $gnuplot_file = 'plot-'.basename($input_file).'-'.date('His', $_SERVER['REQUEST_TIME']).microtime(true).'.png';
  
$log_output['START TIME'] = date('Y-m-d H:i:s', $_SERVER['REQUEST_TIME']);
$log_output['END TIME'] = date('Y-m-d H:i:s');
$log_output['INPUT FILE'] = $input_file;
$log_output['GNUPLOT FILE'] = $num_pushed ? $gnuplot_file : '';
$log_output['ALGORITMH'] = basename($_SERVER['SCRIPT_NAME']);
$log_output['SERIALIZED OPTIONS'] = json_encode($_SERVER['argv']);
$log_output['SESSION TIMEOUT'] = $timeout_session;
$log_output['LOG DATA START'] = date('Y-m-d H:i:s',$begin/1000);
$log_output['LOG DATA END'] = date('Y-m-d H:i:s',$end/1000);
$log_output['LOG LINES'] = $num_total_lines;
$log_output['SESSIONS'] = $num_sessions;
$log_output['PAGELOADS'] = $num_pageloads;
$log_output['TOTAL ASSETS'] = $num_total_assets;
$log_output['CONSIDERED ASSETS'] = $num_assets;
$log_output['IGNORED ENTIRE PAGELOADS'] = $num_not_used_pageloads;
$log_output['ASSETS IN IGNORED PAGELOADS'] = $num_assets_in_bad_pageload;
$log_output['IGNORED ASSETS'] = $num_discarded_assets;
$log_output['IGNORED FAVICONS'] = $num_favicons;
$log_output['IGNORED MOBILE REQUESTS'] = $num_mobile;
$log_output['PAGE FREQUENCY (MEDIAN)'] = $page_frequency_median;
$log_output['PAGE FREQUENCY (3rd QUARTILE)'] = $page_frequency_3rd;
$log_output['ASSET FREQUENCY (MEDIAN)'] = $asset_frequency_median;
$log_output['ASSET FREQUENCY (3rd QUARTILE)'] = $asset_frequency_3rd;
$log_output['NUM URLS AS BOTH PAGE AND ASSET'] = $total_num_dups;
$log_output['UNIQUE URLS AS BOTH PAGE AND ASSET'] = count($dups);
$log_output['PAGELOADS/SESSION'] = round(bcdiv($num_pageloads, $num_sessions),6);
$log_output['ASSETS/PAGELOAD'] = round(bcdiv($num_assets, $num_pageloads),6);
$log_output['NUM PUSHES'] = $num_pushed;
$log_output['NUM MISTAKES'] = $num_mistakes;
$log_output['MISTAKES/PUSHES'] = $num_pushed > 0 ? round(bcdiv($num_mistakes, $num_pushed),6) : 0;
$log_output['PUSHES/ASSETS'] = round(bcdiv($num_pushed, $num_assets),6);
$log_output['PUSHES/LOG LINES'] = round(bcdiv($num_pushed, $num_total_lines),6);
$log_output['NOT PUSHED DUE TO SIZE'] = $num_not_pushed_big;
$log_output['AVERAGE SESSION LENGTH'] = $session_length_average;
$log_output['MEDIAN SESSION LENGTH'] = $session_length_median;
$log_output['CONSIDERED RESOURCES FOR SIZE'] = $have_size > 0 ? count($size_pages)+count($size_assets) : '';
$log_output['TOTAL RESOURCE SIZE'] = $have_size > 0 ? $total_size : '';
$log_output['TOTAL SIZE FOR PAGES'] = $have_size > 0 ? $size_pages_sum : '';
$log_output['TOTAL SIZE FOR ASSETS'] = $have_size > 0 ? $size_assets_sum : '';
$log_output['MEDIAN PAGE SIZE'] = $have_size > 0 ? $size_pages_median : '';
$log_output['MEDIAN ASSET SIZE'] = $have_size > 0 ? $size_assets_median : '';
$log_output['MISTAKES SIZE'] = $have_size > 0 && !empty($size_mistakes) ? $size_mistakes_sum : '';
$log_output['MEDIAN MISTAKE SIZE'] = $have_size > 0 && !empty($size_mistakes) ? $size_mistakes_median : '';

$check_num_pageloads = 0;
$check_num_pushed = 0;
$check_num_assets = 0;
$check_num_mistakes = 0;
$labels = array('1st', '2nd', '3rd', '4th', '5th', 'OTHER');
for($i = 0; $i<=5; ++$i)
{
  $label = $labels[$i];
  if($stat_spec_pageload[$i]['num'] !== count($stat_spec_pageload[$i]['assets'])
    || $stat_spec_pageload[$i]['num'] !== count($stat_spec_pageload[$i]['pushes'])
    || $stat_spec_pageload[$i]['num'] !== count($stat_spec_pageload[$i]['mistakes']))
    bug(__LINE__, $label.' PAGELOADS are  wrong');
  $check_num_pageloads += $log_output[$label.' PAGELOADS NUM'] = $stat_spec_pageload[$i]['num'];
  $check_num_assets += $log_output[$label.' PAGELOADS TOTAL ASSETS'] = !empty($stat_spec_pageload[$i]['assets']) ? array_sum($stat_spec_pageload[$i]['assets']) : '';
  $check_num_pushed += $log_output[$label.' PAGELOADS TOTAL PUSHES'] = !empty($stat_spec_pageload[$i]['pushes']) ? array_sum($stat_spec_pageload[$i]['pushes']) : '';
  $check_num_mistakes += $log_output[$label.' PAGELOADS TOTAL MISTAKES'] = !empty($stat_spec_pageload[$i]['mistakes']) ? array_sum($stat_spec_pageload[$i]['mistakes']) : '';
  $log_output[$label.' PAGELOADS MEDIAN ASSETS'] = !empty($stat_spec_pageload[$i]['assets']) ? $stat_spec_pageload[$i]['assets'][intval(count($stat_spec_pageload[$i]['assets'])/2)] : '';
  $log_output[$label.' PAGELOADS MEDIAN PUSHES'] = !empty($stat_spec_pageload[$i]['pushes']) ? $stat_spec_pageload[$i]['pushes'][intval(count($stat_spec_pageload[$i]['pushes'])/2)] : '';
  $log_output[$label.' PAGELOADS MEDIAN MISTAKES'] = !empty($stat_spec_pageload[$i]['mistakes']) ? $stat_spec_pageload[$i]['mistakes'][intval(count($stat_spec_pageload[$i]['mistakes'])/2)] : '';
}

$log_output['PAGE FREQUENCY STAT'] = json_encode(array_count_values($pages));
$log_output['ASSET FREQUENCY STAT'] = json_encode(array_count_values($assets));
$log_output['HITS PUSHED FOR DIFF PAGELOAD'] = $num_hits_pushed_for_diff_pageload;

if($check_num_pageloads !== $num_pageloads)
  bug(__LINE__, 'num_pageloads is wrong '.($check_num_pageloads - $num_pageloads));
if($check_num_pushed !== $num_pushed)
  bug(__LINE__, 'num_pushed is wrong '.($check_num_pushed  - $num_pushed ));
if($check_num_assets !== $num_assets)
  bug(__LINE__, 'num_assets is wrong '.($check_num_assets - $num_assets));
if($check_num_mistakes !== $num_mistakes)
  bug(__LINE__, 'num_mistakes is wrong '.($check_num_mistakes - $num_mistakes));

  //if($num_pushed > 0)
  //plot_mistakes($title, $gnuplot_file);
  
  if(2 == $option_output)
    echo print_log_header($log_output);
  echo print_log_output($log_output, $option_output);
}

function finish()
{ 
  global $num_total_lines;
  
  if($num_total_lines < 20)
    bug(__LINE__, "less than 20 reqs in file, diying now\n");
  
  check_session_timeout(time() * 2000);
}

function plot_mistakes($title, $gnuplot_file)
{
  global $stat_gnuplot;
  
  $name = 'temp-plotdata-'.$_SERVER['REQUEST_TIME'].'-'.$title;
  $whandle = fopen($name,'w');
  foreach($stat_gnuplot as $key=>$value)
    fwrite($whandle,$key.', '.$value[0].', '.$value[1]."\n");
  fclose($whandle);
  
  			$gnuplot='gnuplot 2>&1 <<- EOF
set term png size 1000, 800
set output "'.$gnuplot_file.'"
set bmargin 3
set title "'.$title.' / '.basename($_SERVER['PHP_SELF']).'"
set y2tics
set xlabel "Requests"
set ylabel "Number of mistakes"
set y2label "Number of pushes"
plot "'.$name.'" using 1:2  wi linespoints t "mistakes", "'.$name.'" using 1:3  wi linespoints t "pushes" axes x1y2
EOF';
  exec ( $gnuplot , $output, $ret);
  if($ret) bug(__LINE__, $ret);
  else unlink($name);
}
?>
