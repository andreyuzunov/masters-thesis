<?php
/*
    Copyright (C) 2013 Andrey Uzunov

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
    [0]=> full string
    string(264) "1234567890 - - [11/Jun/2013:11:29:39 +0300] "GET /abcdef.jpg HTTP/1.1" 200 4417 "http://example.com/style.css" "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20130610 Firefox/23.0""
    [1]=> client
    string(14) "1234567890"
    [2]=> datetime
    string(26) "11/Jun/2013:11:29:39 +0300"
    [3]=> Req method
    string(3) "GET"
    [4]=> req url
    string(54) "/abcdef.jpg"
    [5]=> req version
    string(8) "HTTP/1.1"
    [6]=> resp status
    string(3) "200"
    [7]=> resp size
    string(4) "4417"
    [8]=> referer
    string(60) "http://example.com/style.css"
    [9]=> user-agent
    string(72) "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20130610 Firefox/23.0"
*/

//reorder based on REFERER to put html on first place (hopefully)
function reorder_entries($sessions)
{
  bug(__LINE__, "this is wrong");
  foreach($sessions as &$session)
  {
    if('-' == $session[0][8]) continue;
    
    for($i=0;$i<count($session);$i++)
    {
      $is_first = true;
      for($j=0;$j<count($session);$j++)
      {
        if($i==$j) continue;
        
        if($session[$i][8] == 'http://filmibg.com'.$session[$j][4])
        {
          $is_first = false;
          break;
        }
      }
      if($is_first)
      {
        $temp = $session[$i];
        $session[$i] = $session[0];
        $session[0] = $temp;
        break;
      }
    }
  }
  
  return $sessions;
}


function regexp_log1($row)
{
  $out[0] = $row;
  $pos = strpos($row,' ');
  $out[1] = substr($row,0, $pos);
  if(empty($out[1])) return __LINE__;
  $pos = strpos($row,'[', $pos)+1;
  $pos2 = strpos($row,']', $pos);
  $out[2] = substr($row,$pos, $pos2 - $pos);
  if(empty($out[2])) return __LINE__;
  $pos = strpos($row,'"', $pos2) + 1;
  $pos2 = strpos($row,' ', $pos);
  $out[3] = substr($row,$pos, $pos2 - $pos);
  if(empty($out[3])) return __LINE__;
  $pos = strpos($row,' ', $pos2) + 1;
  $pos2 = min(strpos($row,' ', $pos),strpos($row,'"', $pos));
  $out[4] = substr($row,$pos, $pos2 - $pos);
  if(empty($out[4]) && '0' !== $out[4]) return __LINE__;
  if('"' == $row[$pos2])
  {
    $pos = $pos2 + 2;
    $pos2 = strpos($row,' ', $pos);
  }
  else
  {
    $pos = strpos($row,'"', $pos2) + 2;
    $pos2 = strpos($row,' ', $pos);
  }
  $out[6] = substr($row,$pos, $pos2 - $pos);
  if(empty($out[6])) return __LINE__;
  $pos = $pos2 + 1;
  $pos2 = strpos($row,' ', $pos);
  $out[7] = substr($row,$pos, $pos2 - $pos);
  if($out[7] !== '0' && empty($out[7])) return __LINE__;
  $pos = $pos2 + 2;
  $pos2 = strpos($row,'"', $pos);
  $out[8] = substr($row,$pos, $pos2 - $pos);
  $pos = $pos2 + 3;
  $pos2 = strpos($row,'"', $pos);
  $out[9] = substr($row,$pos, $pos2 - $pos);
  
  return $out;
}


function regexp_log_simple($row)
{
  $out[0] = $row;
  $pos = strpos($row,' ');
  $out[1] = substr($row,0, $pos);
  if(empty($out[1])) return __LINE__;
  $pos = strpos($row,'[', $pos)+1;
  $pos2 = strpos($row,']', $pos);
  $out[2] = substr($row,$pos, $pos2 - $pos);
  if(empty($out[2])) return __LINE__;
  $pos = strpos($row,'"', $pos2) + 1;
  $pos2 = strpos($row,' ', $pos);
  $out[3] = substr($row,$pos, $pos2 - $pos);
  if(empty($out[3])) return __LINE__;
  $pos = strpos($row,' ', $pos2) + 1;
  $pos2 = min(strpos($row,' ', $pos),strpos($row,'"', $pos));
  $out[4] = substr($row,$pos, $pos2 - $pos);
  if(empty($out[4])) return __LINE__;
  if('"' == $row[$pos2])
  {
    $pos = $pos2 + 2;
    $pos2 = strpos($row,' ', $pos);
  }
  else
  {
    $pos = strpos($row,'"', $pos2) + 2;
    $pos2 = strpos($row,' ', $pos);
  }
  $out[6] = substr($row,$pos, $pos2 - $pos);
  if(empty($out[6])) return __LINE__;
  $pos = $pos2 + 1;
  $pos2 = strpos($row,"\n", $pos);
  $out[7] = substr($row,$pos, $pos2 - $pos);
  
  return $out;
}


function myErrorHandler($errno, $errstr, $errfile, $errline)
 {
   fprintf( STDERR, "ERROR: $errno: $errstr in $errfile on line $errline\n");
   die;
 }

function print_log_output($log, $csv)
{
  if($csv)
  {
    return implode('; ', $log).";\n";
  }
  
  $output = '';
  foreach($log as $key => $value)
  {
    $output .= "$key: $value\n";
  }
  return $output;
}

function print_log_header($log)
{
  return implode('; ', array_keys($log)).";\n";
}

function bug($line, $str='')
{
  echo 'ERROR: ';
  echo "bug at line $line\n";
  echo $str;
  die;
}

function varDumpToString ($var)
{
    ob_start();
    var_dump($var);
    $result = ob_get_clean();
    return $result;
}
?>
