<?php
/*
    Copyright (C) 2013 Andrey Uzunov

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
 * consider 
 * 1. how often a resource R is requested within a pageload
 * for a page P: probability R/P
 * 2. Do not push a resource already sent for the session or wrongly pushed
 * 3. Keep statistics if an url is a resource or page and push only 
 * resources.
 * 4. Max num of pushed resources per page can be used
 */

$stat_pageload = array();
$history = array();

function uasort_cmp($a, $b) {
    return -bccomp($a, $b, 3);
}

function cb_timedout_session($session_id, $timestamp_ms)
{
}


function cb_new_session($session_id, $timestamp_ms)
{
}


function cb_reuse_session($session_id, $timestamp_ms)
{
}


function cb_request_resource($session_id, $timestamp_ms, $url)
{
  global $stat_pageload;
  global $num_push_hits;
  global $sessions;
  global $dups;
  global $cur_browser;
  global $history;
  global $option_history;
  global $num_hits_pushed_for_diff_pageload;
  
  if($option_history > 0)
    $history[$session_id][$url] = $timestamp_ms;
  
  $pageload = &$sessions[$session_id]['pageloads'][count($sessions[$session_id]['pageloads']) - 1];
  $first_url = $pageload['first_url'];
  
  if(count($pageload['resources']) === count(array_unique($pageload['resources'])))
  {
    if(!empty($stat_pageload[$cur_browser['browser']][$first_url]))
    {
    if(empty($stat_pageload[$cur_browser['browser']][$first_url]['followers'][$url]))
    {
      $stat_pageload[$cur_browser['browser']][$first_url]['followers'][$url] = 1;
    }
    else
    {
      ++$stat_pageload[$cur_browser['browser']][$first_url]['followers'][$url];
    }
    ++$stat_pageload[$cur_browser['browser']][$first_url]['num_followers'];
    }
  }
  
  foreach($sessions[$session_id]['pageloads'] as $k=>$pload)
  {
    //check for pushed resource
    if(!empty($pload['pushed'][$url]))
    {
      //push hit
      ++$num_push_hits;
      --$pload['pushed'][$url];
      if($k != count($sessions[$session_id]['pageloads']) - 1)
        ++$num_hits_pushed_for_diff_pageload;
      if(empty($pload['pushed'][$url]))
        unset($sessions[$session_id]['pageloads'][$k]['pushed'][$url]);
    }
  }
  
  unset($pageload);
}


function cb_request_page($session_id, $timestamp_ms, $url)
{
  global $sessions;
  global $stat_pageload;
  global $num_pushed;
  global $debug_pushed_dups;
  global $threshold_num;
  global $threshold_num_to_push;
  global $threshold_ratio;
  global $dups;
  global $cur_browser;
  global $history;
  global $option_history;
  
  if($option_history > 0)
    $history[$session_id][$url] = $timestamp_ms;
  
  $pageload = &$sessions[$session_id]['pageloads'][count($sessions[$session_id]['pageloads']) - 1];
  if(empty($stat_pageload[$cur_browser['browser']][$url]))
  {
    $stat_pageload[$cur_browser['browser']][$url]['num'] = 1;
    $stat_pageload[$cur_browser['browser']][$url]['num_followers'] = 0;
    $stat_pageload[$cur_browser['browser']][$url]['followers'] = array();
  }
  else
  {
    //push 
    
    if($stat_pageload[$cur_browser['browser']][$url]['num'] >= $threshold_num)
    {
      $to_push = array();
      $session_resources = array();
      foreach($sessions[$session_id]['pageloads'] as $pload)
      {
        $session_resources[$pload['first_url']] = 1;
        foreach($pload['resources'] as $res)
          $session_resources[$res] = 1;
        if(!empty($pload['pushed']))
          foreach($pload['pushed'] as $pushed_url => $res)
            $session_resources[$pushed_url] = 1;
      }
      foreach($stat_pageload[$cur_browser['browser']][$url]['followers'] as $f_url=>$f_num)
      {
        if(!isset($session_resources[$f_url]) && is_asset($f_url) && (0 == $option_history || !isset($history[$session_id][$f_url])) && is_allowed_for_push($f_url))
        {
          $first_prob = bcdiv($f_num,$stat_pageload[$cur_browser['browser']][$url]['num'],3);
          if(bccomp(1, $first_prob, 3) < 0)
          {
            $str = $first_prob.'; '.$f_url.'; '.$url."\n";
            $first_prob = 1;
            bug(__LINE__, $str);
          }
          if(bccomp($threshold_ratio, $first_prob,3) <= 0)
          {
            if(isset($to_push[$f_url]))
            {
              ++$debug_pushed_dups;
            }
            else
            {
              $to_push[$f_url] = $first_prob;
            }
          }
        }
      }
      
      uasort($to_push, 'uasort_cmp');
      $i = 0;
      foreach($to_push as $f_url=>$prob)
      {
        if($threshold_num_to_push > 0 && $i == $threshold_num_to_push) break;
        $pageload['pushed'][$f_url]=1;
        ++$num_pushed;
        ++$i;
      }
    }
  
    ++$stat_pageload[$cur_browser['browser']][$url]['num'];
  }
  
  if(!isset($pageload['pushed']))
    $pageload['pushed'] = array();
  unset($pageload);
}
?>
