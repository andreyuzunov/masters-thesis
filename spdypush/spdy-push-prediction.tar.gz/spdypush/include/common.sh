#!/bin/bash -e

#    Copyright (C) 2013 Andrey Uzunov
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

DIR=`dirname $0`
ALGOS_LOG="push-algos.csv"
BATCH_LOG="push-batch.log"
INPUT="$1"
BASE_INPUT=`basename "$1"`
LINES="0"

NOW=`date +"%Y%m%d-%H%M%S"`
COMMON_FILENAME="${DOMAIN}-${NOW}"

writelog()
{	
  NOW=`date +"%Y-%m-%d %T.%N"`
	echo "[${NOW}] ${$} ${1}" >> "$BATCH_LOG"
}

loglines()
{
  LINES=`wc -l "$1" | egrep '^[0-9]+' -o`
  
  writelog "$LINES lines in file $1"
}

run_test()
{
  writelog "Run algo '${1}'..."
  
  COMMAND="php $DIR/${1}"
  
  set +e
  PHPOUT=`$COMMAND 2>&1`
  set -e
  
  ISOK=`echo "$PHPOUT" | head -n1 | egrep '^((20)|(START TIME;)).+;$' | wc -l | egrep '^[0-9]+' -o`
  
  if [ "$ISOK" -eq "1" ]
  then
    echo "$PHPOUT" >> "$ALGOS_LOG"
    writelog "PHP wrote a CSV line"
  else
    writelog "PHP error: ${PHPOUT}"
  fi
}

writelog "STARTED for domain '${DOMAIN}' and input log file '${INPUT}'"

loglines "$INPUT"

FIRSTLINE_DATE=`head -n1 "$1" | egrep -io '[0-9]{2}/[a-z]{3}/[0-9]{4}' | sed -e 's|/|\ |g' `
writelog "First line's date ${FIRSTLINE_DATE}"
LASTLINE_DATE=`tail -n1 "$1" | egrep -io '[0-9]{2}/[a-z]{3}/[0-9]{4}' | sed -e 's|/|\ |g' `
