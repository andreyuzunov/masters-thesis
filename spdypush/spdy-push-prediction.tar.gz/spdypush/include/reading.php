<?php
/*
    Copyright (C) 2013 Andrey Uzunov

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
require_once(dirname(__FILE__).'/functions.php');
require_once(dirname(__FILE__).'/generic.php');

$handle = fopen($input_file, "r");

if ($handle)
{
  while (($line = fgets($handle)) !== false)
  {
    if($option_log_format > 0)
    $out = regexp_log_simple($line);
    else
    $out = regexp_log1($line);
    if(!is_array($out))
    {
      $str = varDumpToString($out);
      $str.=varDumpToString($line);
      bug(__LINE__,$str);
    }
    
    if($option_log_format > 0)
    $out[9] = '';
    parse_request($out[1].'='.$out[9], strtotime($out[2]) * 1000, $out[4], $out[6], $out[3], $out[9], $out[7]);
  }

  if (!feof($handle))
  {
    bug(__LINE__, 'unexpected fgets() fail');
  }
  fclose($handle);
  
  finish();
  
  print_general_stat(basename($input_file));
}
?>
