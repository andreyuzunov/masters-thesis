<?php
/*
    Copyright (C) 2013 Andrey Uzunov

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
require_once(dirname(__FILE__).'/include/functions.php');
set_error_handler("myErrorHandler");
if($argc != 3)
bug(__LINE__, "usage: input-file output-file\n");

$handle = fopen($argv[1], 'r');
$whandle = fopen($argv[2], 'w');

if(!$handle) bug(__LINE__);
if(!$whandle) bug(__LINE__);

$browscap_filtered = 0;

$written = 0;

$uas_flags = array();
$uas_arrays = array();

while (($line = fgets($handle)) !== false)
{  
  $new_line = rtrim($line);
  $ua = substr($new_line,strrpos($new_line,'"',-2)+1,-1);

  if(!isset($uas_flags[$ua]))
  {
    $beg = time();
    $browser = get_browser($ua, true);
    if($ua !== '%' && ( false != $browser['crawler'] || 'DefaultProperties' === $browser['browser'] || 'Default Browser' === $browser['browser']))
    {
      $uas_flags[$ua] = 0;
      $browscap_filtered++;
      continue;
    }
    else
    {
      $uas_arrays[$ua] = $browser;
      unset($uas_arrays[$ua]['browser_name_regex']);
      $uas_flags[$ua] = 1;
    }
  }
  else if(0 === $uas_flags[$ua])
  {
    $browscap_filtered++;
    continue;
  }

  $written++;
  fwrite($whandle,$line);
}

fclose($handle);

fclose($whandle);
  
if(empty($uas_arrays))
  bug(__LINE__, 'uas_arrays');

$json = json_encode($uas_arrays);
    
if(empty($json))
{
	var_dump($uas_arrays);
  bug(__LINE__, 'json'.json_last_error());
}
  
$uas_cache_file = $argv[2].'-browsers-cache';
$ret = file_put_contents($uas_cache_file, $json);
    
if(!($ret > 0))
  bug(__LINE__, 'file_put_contents');

echo $browscap_filtered." lines filtered by browscap.ini.\n";
echo $written." lines written.\n";
echo $uas_cache_file." file written (browser cache for next scritps).\n";
echo count($uas_arrays)." different browsers.\n";
?>
