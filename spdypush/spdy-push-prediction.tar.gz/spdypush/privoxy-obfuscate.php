<?php
#    Copyright (C) 2013 Andrey Uzunov
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

require_once(dirname(__FILE__).'/include/functions.php');
set_error_handler("myErrorHandler");
if($argc != 3)
bug(__LINE__, "usage: input-file output-file\n");

define('POS',44);

$handle = fopen($argv[1], 'r');
$whandle = fopen($argv[2], 'w');

if(!$handle) bug(__LINE__);
if(!$whandle) bug(__LINE__);

$written = 0;

$hosts = array();
$host_paths = array();

while (($line = fgets($handle)) !== false)
{
  $begining = strpos($line,' ',POS) + 1;
  $end=strpos($line,' ',$begining);
  $url = substr($line,$begining,$end-$begining);
  if(0 === strpos($url,'http://'))
  {
    $pos = strpos($url,'/',7);
    $pre='http://';
  }
  else
  {
    $pos = strlen($url);
    $pre='';
  }
  $host = substr($url,0,$pos);
  $path = substr($url,$pos+1);
  
  if(!isset($hosts[$host]))
    $hosts[$host] = count($hosts);
  if(!empty($path))
  {
    if('favicon.ico' == $path)
      $host_path = $path;
    else
    {
      if(!isset($host_paths[$host.'/'.$path]))
        $host_paths[$host.'/'.$path] = count($host_paths);
      $host_path = $host_paths[$host.'/'.$path];
    }
  }
  else $host_path = '';
  
	  $new_line = substr($line,0,$begining).$pre.$hosts[$host].'/'.$host_path.substr($line,$end);
	  $written++;
      fwrite($whandle,$new_line);
}

fclose($handle);

fclose($whandle);
  
echo $written." lines written.\n";
?>
